<?php include('elements/header.php');
    if($_SESSION['user_data']['user_role']=='admin'){
       $sql = "SELECT * from `users` WHERE level!=0";
    } else {
      $parent = $_SESSION['user_data']['id'];
      $sql    = "SELECT * FROM `users` WHERE parent_ids LIKE '%$parent%'"; 
    }
	  $query = mysqli_query($db,$sql); 
	  $users = array();
	  while($row = mysqli_fetch_assoc($query)){
	     $users[] = $row;
	  }
	  
 ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Users</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
              <li class="breadcrumb-item active">Users</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->

      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
         
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
      <div class="row">
          <div class="col-11 mb-3">

        <a href="user_form.php" class="btn btn-success float-right">Add User</a>
        <?php if($_SESSION['user_data']['level'] > 5) { ?>
            <a href="user_form.php" class="btn btn-success float-right mr-3" data-toggle="modal" data-target="#exampleModal">Record Sale</a>
        <?php } ?>

          </div>
          </div>
      
      <div class="card col-lg-11">

              <div class="card-header">
                <h3 class="card-title">Users List</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive">
                                     
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
            <th>Sl.No</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
          <?php $i=1;
            foreach($users as $row) { ?>
             
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo 'Level '.$row['level']; ?></td>
            
            <td class="actions">
              <a href="user_form.php?id=<?php echo $row['id']; ?>" class="secondary" title="Edit"><i class="nav-icon fas fa-pen"></i>&nbsp;Edit</a>
          </td>
          </tr>
          <?php $i++;
          } 
          ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
 <?php include('elements/footer.php'); ?>