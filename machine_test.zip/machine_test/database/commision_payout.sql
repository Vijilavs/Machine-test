-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2024 at 08:03 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `commision_payout`
--

-- --------------------------------------------------------

--
-- Table structure for table `payouts`
--

CREATE TABLE `payouts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payouts`
--

INSERT INTO `payouts` (`id`, `user_id`, `sale_id`, `amount`, `created_at`) VALUES
(6, 7, 12, '10.00', '2024-09-30 10:23:47'),
(7, 14, 12, '5.00', '2024-09-30 10:23:47'),
(8, 15, 12, '3.00', '2024-09-30 10:23:47'),
(9, 16, 12, '2.00', '2024-09-30 10:23:48'),
(10, 17, 12, '1.00', '2024-09-30 10:23:48');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `user_id`, `amount`, `created_at`) VALUES
(12, 18, '100.00', '2024-09-30 10:23:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `parent_ids` varchar(255) DEFAULT NULL,
  `level` int(11) DEFAULT 0,
  `user_role` varchar(20) NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone`, `parent_ids`, `level`, `user_role`, `created_at`) VALUES
(1, 'Admin', 'admin@localhost.com', 'e10adc3949ba59abbe56e057f20f883e', '0123456789', NULL, 0, 'admin', '2024-09-29 07:52:03'),
(7, 'First Level', 'firstleveluser@gmail.com', '9a81f217f72f15c6ed039f3e9e37281e', '0123456789', '0', 1, 'user', '2024-09-29 18:28:10'),
(14, 'Second Level', 'secondleveluser@gmail.com', '4d100f4c30a2684ca516ca579d15703a', '0123456789', '7', 2, 'user', '2024-09-30 05:18:26'),
(15, 'Third Level  User', 'thirdleveluser@gmail.com', '1fb5c1d7ea5e8a0b5a70758cb229914e', '0123456789', '7,14', 3, 'user', '2024-09-30 05:23:41'),
(16, 'Fourth Level', 'fourthleveluser@gmail.com', '565c2ec550812f0e3e9c0e8a705d304e', '0123456789', '7,14,15', 4, 'user', '2024-09-30 05:26:23'),
(17, 'Level 5 User', 'fifthleveluser@gmail.com', '1bf4e26c8ebf91c6e2617dd5d5e97cb3', '0123456789', '7,14,15,16', 5, 'user', '2024-09-30 05:31:21'),
(18, 'Sixth Level', 'sixthleveluser@gmail.com', '1381f246194d7293e987f8527c5ec309', '0123456789', '7,14,15,16,17', 6, 'user', '2024-09-30 05:39:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payouts`
--
ALTER TABLE `payouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payouts`
--
ALTER TABLE `payouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payouts`
--
ALTER TABLE `payouts`
  ADD CONSTRAINT `payouts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `payouts_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
