<?php
$db_host = "localhost";
$db_user = "root";
$db_password = "";
$db_database ="commision_payout";

$db = mysqli_connect($db_host,$db_user,$db_password,$db_database) or die("Connection Error: " . mysqli_error($db)) ;

?>
