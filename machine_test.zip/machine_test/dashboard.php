<?php include('elements/header.php');
    $parent = $_SESSION['user_data']['id'];
    // get count of all users for admin (or) else count of all users under the current user
    if($_SESSION['user_data']['user_role']=='admin'){
       $sql = "SELECT COUNT('id')as count from `users` WHERE level!=0";
    } else {
      $sql = "SELECT COUNT('id')as count from `users` WHERE parent_ids LIKE '%$parent%'"; 
    }
    
	  $query = mysqli_query($db,$sql); 
	  $result = mysqli_fetch_assoc($query);
	  $users_count = $result['count'];

    // get count of all sales for admin (or) else count of sales of users under the current user
    if($_SESSION['user_data']['user_role']=='admin'){
       $sql = "SELECT COUNT('id')as count from `sales`";
    } else {
      $sql = "SELECT COUNT('id') as count,users.parent_ids,users.id FROM (sales INNER JOIN users ON sales.user_id=users.id) WHERE users.parent_ids LIKE '%$parent%' OR users.id = $parent";
    }
    $query = mysqli_query($db,$sql); 
    $result = mysqli_fetch_assoc($query);
    $sale_count = $result['count'];
    
    // get count of all payouts for admin (or) else count of payouts of users under the current user
    if($_SESSION['user_data']['user_role']=='admin'){
       $sql = "SELECT COUNT('id')as count from `payouts`";
    } else {
      $sql = "SELECT COUNT('id') as count,users.parent_ids,users.id FROM (payouts INNER JOIN users ON payouts.user_id=users.id) WHERE users.parent_ids LIKE '%$parent%' OR users.id = $parent";
    }

    
    $query = mysqli_query($db,$sql); 
    $result = mysqli_fetch_assoc($query);
    $payout_count = $result['count'];

 ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo $users_count; ?></h3>

                <p>Users</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="members.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
       
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo $sale_count; ?></h3>

                <p>Sales</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="sales.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo $payout_count; ?></h3>

                <p>Payouts</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="payouts.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
 <?php include('elements/footer.php'); ?>