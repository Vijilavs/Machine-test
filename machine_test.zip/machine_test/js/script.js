/*!
 * script type - text/javascript
 * scripts for payout system admin 
 */
 // form alert
  $(".form-alert").fadeOut(3000);
  
//function to confirm delete
 function checkDelete(){
   return confirm('Are you sure?');
}


// script to check email already exist in users table
   $("#userEmail").blur(function() {
    var email = $('#userEmail').val();
      if(email == '') {
        return;
      }
      $.ajax({
          url: 'functions.php',
          type: 'post',
          data: {
            'email':email,
            'email_check':1,
        },
        dataType: 'JSON',
        success:function(response) {  
         $("#email_error").remove();
          if(response.status =="error") { 
              $("#userEmail").after("<span id='email_error' style='color:red'>"+response.message+"</span>");
              $("#userButton").prop('disabled', true); //disable 
             
           } else {
              $("#userButton").prop('disabled', false); 
           }
         
        },
        error:function(e) {
          $("#result").html("Something went wrong");
        }
  });
});


//userAddForm add/edit form validation
 $("#userAddForm").validate({
    rules: {
    username: "required",
    email: { required :true,
             email : true,
           },
    phone: {
        required: true,
        minlength: 10,
        maxlength: 10
    },
    
    },
    messages: {
    username: "Please enter user name",
    
    email : { required:"Please enter Email",
              email : "Please enter valid email id",
    },
    phone : {  
         required:"Please enter phone",
         minlength:"Please enter your 10 digit phone",
         maxlength:"Please enter valid mobile number",
    },
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    },
  
  });

 
 //saleAddForm add form validation
 $("#recordSale").validate({
    rules: {
    amount: { required :true,
              number : true,
           },
    },
    messages: {
    
    amount : { required:"Please enter Amount",
              email : "Please enter valid number",
    },
   
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    },
  
  });


 