<?php 
/* functions to manage payout system dashbord
   @ Author  Vijila 
*/
session_start();
include('database/db_config.php');


/*  check email exists in users table*/
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email_check']) && $_POST['email_check'] == 1) {
            $email = mysqli_real_escape_string($db, $_POST['email']);
            $sqlcheck = "SELECT email FROM users WHERE email = '$email' ";
            $checkResult = $db->query($sqlcheck);
            if($checkResult->num_rows > 0) {
                $response = array('status'=>'error','message'=>'Sorry! email already exists.');
            }else {
                $response = array('status'=>'success' ,'message'=>'');
            }
    echo json_encode($response);
}

//function to generate password
function generatePassword($length) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789*@()';
    $charactersLength = strlen($characters);
    $randomPassword = '';

    for ($i = 0; $i < $length; $i++) {
        $randomIndex = rand(0, $charactersLength - 1);
        $randomPassword .= $characters[$randomIndex];
    }

    return $randomPassword;
}

//function to add user by admin/higherlevel users 
if(isset($_POST['add-user'])){
   $username = trim($_POST['username']);
   $phone    = trim($_POST['phone']);
   $email  	 = trim($_POST['email']);
   $level    = $_POST['level'];
   $parent_id = $_POST['parent_id'];
   $password = generatePassword(8);
   $pass_hash = md5($password);
   
   $sql = "INSERT INTO `users`(`id`, `username`, `email`, `password`, `phone`, `parent_ids`, `level`) VALUES ('','$username','$email','$pass_hash','$phone','$parent_id','$level')";
        if (mysqli_query($db,$sql) === TRUE) {
		           
			       // codes to send email to user
			
			             $toEmail = $email;
                         $mailHeaders = "From: Payout Machine Test<vijilavijayan2012@gmail.com>\r\n";
       		             $mailHeaders .= "MIME-Version: 1.0\r\n";
                         $mailHeaders .= "Content-Type: text/html; charset=UTF-8\r\n";
        	             $subject = 'Welcome To Multilevel Affiliate Payout System';
        	             $content = '<div class="text-center">
                                     Hi,'. $username.'<h4>Thanks for joining with us!</h4>
									 <p> Please login to your account using the following:<br>
                                     </p><p>email :'.$email.'<br/>Password :'.$password.'<br/></p>
									 </div>'; 

                        // to get generated password  because, localhost does not support php mail function            
                       // print_r($content); die();
                        
                        $sendMail = mail($toEmail, $subject, $content, $mailHeaders);
                   
	  	 	 		    $_SESSION['message'] = '<p class="success">User Added successfully.Login credentials sent to your email.</p>';
       		 		    header('Location: members.php');
		
		} else {
			
			        $_SESSION['message'] = '<p class="error">Unable to add user</p>';
       		 		header('Location: ' . $_SERVER['HTTP_REFERER']);
		}
	
}


//function to update user by admin/ higher level user
if(isset($_POST['update-user'])){ 
   $u_id  = $_POST['user_id'];
   $username = $_POST['username'];
   $phone    = $_POST['phone'];
   $email  	 = $_POST['email'];
   $level    = $_POST['level'];
   $parent_id = $_POST['parent_id'];
   
   $sql = "UPDATE `users` SET `username`='$username',`email`='$email',`phone`='$phone',`parent_ids`='$parent_id',`level`='$level' WHERE id='$u_id'";
	
    if (mysqli_query($db,$sql) === TRUE) {
	
	  	 	 		$_SESSION['message'] = '<p class="success">Updated successfully</p>';
       		 		header('Location: members.php');
	} else {
			
			        $_SESSION['message'] = '<p class="error">Unable to Update</p>';
       		 		header('Location: ' . $_SERVER['HTTP_REFERER']);
		}
	
}


// function to delete user
/*if(isset($_GET['del_uId']) && $_GET['del_uId']!=''){
	$del_id = $_GET['del_uId'];
	$sql = "DELETE FROM `users` WHERE id='$del_id'";
	if(mysqli_query($db,$sql)==TRUE){
		 $_SESSION['message'] = '<p class="success">Deleted successfully</p>';
       	 header('Location: members.php');
	} else {
		$_SESSION['message'] = '<p class="error">Unable to Delete</p>';
       	header('Location: members.php');
	}
	
}*/

//function to add sale by 6th level users 
if(isset($_POST['record_sale'])){
   $user_id  = $_POST['user_id'];
   $amount   = $_POST['amount'];
   
   
   $sql = "INSERT INTO `sales`(`id`, `user_id`, `amount`) VALUES ('','$user_id','$amount')";
        if (mysqli_query($db,$sql) === TRUE) {
                    $sale_id = mysqli_insert_id($db);
                    // Distribute payouts
                    distributePayouts($user_id, $sale_id, $amount);
                    $_SESSION['message'] = '<p class="success">Sale Recorded successfully</p>';
                    header('Location: sales.php');
        
        } else {
            
                    $_SESSION['message'] = '<p class="error">Unable to add sale</p>';
                    header('Location: ' . $_SERVER['HTTP_REFERER']);
        }
    
}

//function to distribute commission
function distributePayouts($user_id, $sale_id, $amount) {
    global $db;
    // select parents of user who make sale
    $sql    = "SELECT parent_ids FROM `users` WHERE id='$user_id'";
    $query  = mysqli_query($db,$sql);
    $result = mysqli_fetch_object($query);
    $parentIds = $result->parent_ids;
    $parentsArr = explode(',', $parentIds);
    for($i=0; $i<=4;$i++){
        $user = $parentsArr[$i];
        $commission ='';
        if($i==0){
            $percentage = 10;
        } else if($i==1){
            $percentage = 5;
        } else if($i==2){
            $percentage = 3;
        } else if($i==3){
            $percentage = 2;
        } else if($i==4){
            $percentage = 1;
        } else {}

        $commission = ($amount * $percentage) / 100;

    $sql = "INSERT INTO `payouts`(`id`, `user_id`, `sale_id`, `amount`) VALUES ('','$parentsArr[$i]','$sale_id','$commission')";
    mysqli_query($db,$sql);    

    }

   return true;


}








?>