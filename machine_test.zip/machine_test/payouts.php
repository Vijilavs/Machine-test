<?php include('elements/header.php');

   if($_SESSION['user_data']['user_role']=='admin'){
       $sql = "SELECT `payouts`.*,users.username,users.level,sales.id as sale_id,sales.amount as sale_amount FROM ((payouts INNER JOIN users ON payouts.user_id=users.id) INNER JOIN sales ON payouts.sale_id=sales.id)";
     } else {
        $parent = $_SESSION['user_data']['id'];
        $sql = "SELECT `payouts`.*,users.username,users.level,sales.id as sale_id,sales.amount as sale_amount FROM ((payouts INNER JOIN users ON payouts.user_id=users.id) INNER JOIN sales ON payouts.sale_id=sales.id) WHERE users.parent_ids LIKE '%$parent%' OR users.id = $parent"; 
     }
    
	  $query = mysqli_query($db,$sql); 
	  $payouts = array();
	  while($row = mysqli_fetch_assoc($query)){
	     $payouts[] = $row;
	  }
	  
 ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Payouts</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
              <li class="breadcrumb-item active">Payouts</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->

      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
         
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
      
      <div class="card col-lg-11">

              <div class="card-header">
                <h3 class="card-title">Payouts List</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive">
                                     
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Sl.No</th>
                    <th>User Name</th>
                    <th>User Level</th>
                    <th>Sale Id</th>
                    <th>Sale Amount</th>
                    <th>Payout Amount</th>
                  
                  </tr>
                  </thead>
                  <tbody>
          <?php $i=1;
            foreach($payouts as $row) { ?>
             
          <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo 'Level '.$row['level']; ?></td>
            <td><?php echo $row['sale_id']; ?></td>
            <td><?php echo $row['sale_amount']; ?></td>
            <td><?php echo $row['amount']; ?></td>
            
           
          </tr>
          <?php $i++;
          } 
          ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
 <?php include('elements/footer.php'); ?>